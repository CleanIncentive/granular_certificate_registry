---
name: Issue template
about: Core issue template for Tariff Tribe backend
title: Backend
labels: ''
assignees: ClemAtt

---

## Description

- What the ticket should be about. No need to repeat things if they’re going to be in the Success Criteria section

## Dependencies

- with third parties, data etc.

## Tests

- [] What tests are needed to accomplish the success criteria

## Success Criteria

- [] Checkboxes describing every step needed to be taken for defining this ticket as Done.
